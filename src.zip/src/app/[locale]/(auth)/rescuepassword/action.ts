'use server'

import { env } from "@/env"

export async function sendRecoveryEmail(email: object) {
    const response = await fetch(`${env.NEXT_PUBLIC_DOMAIN_FRONT}/api/recovery/token`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(email)
    })

    const res = await response.json()

    if (!response.ok) return {err: {...res}}

    return {ok: true}
}

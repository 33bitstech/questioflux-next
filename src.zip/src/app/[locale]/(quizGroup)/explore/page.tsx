import React from 'react'
import styles from './explore.module.scss'
import ContextualHeaderActions from '@/components/NavigateWidgets/contextual-header-action'
import SearchResults from '@/components/Searching/search-results'
import FeaturedsContainer from '@/components/Searching/featureds-container'
import { env } from '@/env'
import { generateExploreQuizSchema } from '@/utils/generateSchemas'
import { getTranslations } from 'next-intl/server'
import { Metadata } from 'next'
import GoogleAd from '@/components/Google/GoogleAd'
import { getQuizzes, getFeaturedsQuizzes } from './actions'
import { getOpenGraphLocale } from '@/utils/locale'

interface IProps {
    params: Promise<{ locale: string }>
    searchParams?: Promise<{
        title?: string
        tags?: string
        categories?: string
        typeQuiz?: string
    }>
}

export async function generateMetadata({ params }: IProps): Promise<Metadata> {
    const { locale } = await params
    const t = await getTranslations({ locale, namespace: 'explorePage' });

    const langs = {
        'es': `${env.NEXT_PUBLIC_DOMAIN_FRONT}/es/explore`,
        'en-US': `${env.NEXT_PUBLIC_DOMAIN_FRONT}/en/explore`,
        'pt-BR': `${env.NEXT_PUBLIC_DOMAIN_FRONT}/pt/explore`,
        'x-default': `${env.NEXT_PUBLIC_DOMAIN_FRONT}/en/explore`
    }

    return {
        title: t('metadataTitle'),
        description: t('metadataDesc'),
        robots: 'index, follow',
        keywords: "quiz, explore, play",
        alternates: {
            canonical: `${env.NEXT_PUBLIC_DOMAIN_FRONT}/${locale}/explore`,
            languages: langs
        },
        openGraph: {
            title: t('metadataTitle'),
            description: t('metadataDesc'),
            url: `${env.NEXT_PUBLIC_DOMAIN_FRONT}/${locale}/explore`,
            siteName: 'QuestioFlux',
            images: `${env.NEXT_PUBLIC_DOMAIN_FRONT}/quiz_padrao_preto.png`,
            locale: getOpenGraphLocale(locale),
            type: 'website',
        },
        twitter: {
            card: 'summary_large_image',
            title: t('metadataTitle'),
            description: t('metadataDesc'),
            images: [`${env.NEXT_PUBLIC_DOMAIN_FRONT}/quiz_padrao_preto.png`],
        }
    }
}

export default async function Explore({ params, searchParams }: IProps) {
    const { locale } = await params;
    const query = await searchParams;

    const t = await getTranslations({ locale, namespace: 'explorePage' });

    const [paginatedData, popularQuizzes] = await Promise.all([
        getQuizzes({
            page: 1,
            title: query?.title,
            tags: query?.tags,
            categories: query?.categories,
            typeQuiz: query?.typeQuiz,
        }),
        getFeaturedsQuizzes()
    ])

    const quizzes = paginatedData?.quizzes ?? []
    const totalPages = paginatedData?.totalPages ?? 1
    const total = paginatedData?.total ?? quizzes.length
    const baseUrl = `${env.NEXT_PUBLIC_DOMAIN_FRONT}/${locale}`;

    const itemListSchema = {
        '@context': 'https://schema.org',
        '@type': 'ItemList',
        'name': t('metadataTitle'),
        'description': t('metadataDesc'),
        'numberOfItems': total,
        'itemListElement': quizzes.map((quiz, index) => ({
            '@type': 'ListItem',
            'position': index + 1,
            'item': generateExploreQuizSchema(quiz, baseUrl, env.NEXT_PUBLIC_DOMAIN_FRONT)
        })),
    };

    return (
        <main className={styles.content}>
            <nav className={styles.div_buttons_links}>
                <ContextualHeaderActions page='explore' locale={locale} />
            </nav>

            <script
                type="application/ld+json"
                dangerouslySetInnerHTML={{ __html: JSON.stringify(itemListSchema) }}
            />

            <FeaturedsContainer styles={styles} defaultQuizzes={popularQuizzes ?? []} />

            <GoogleAd slot='9817632261' />

            <div className={styles.results}>
                <h1>{t('mainTitle')}</h1>
                <SearchResults
                    styles={styles}
                    defaultQuizzes={quizzes}
                    totalPages={totalPages}
                />
            </div>
            <GoogleAd slot='3850989716' />
        </main>
    )
}
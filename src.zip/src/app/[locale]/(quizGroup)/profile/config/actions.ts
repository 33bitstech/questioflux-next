'use server'

import { env } from "@/env"
import { getCookieHeader } from "@/utils/getCookieHeader"
import { revalidatePath } from "next/cache"
import { cookies } from "next/headers"

export async function verifyUserPremium(revalidate: boolean = true) {
    const cookieStore = await cookies()
    const cookieHeader = getCookieHeader(cookieStore.getAll())

    const response = await fetch(`${env.NEXT_PUBLIC_DOMAIN_FRONT}/api/user/verify-premium`, {
        method: 'GET',
        headers: { 'cookie': cookieHeader },
    })

    const res = await response.json()
    if (!response.ok) return { err: res.message }
    if (revalidate) revalidatePath('/profile/config')
    return { premium: res }
}

export async function cancelSubscription() {
    const cookieStore = await cookies()
    const cookieHeader = getCookieHeader(cookieStore.getAll())

    const response = await fetch(`${env.NEXT_PUBLIC_DOMAIN_FRONT}/api/user/cancel-subscription`, {
        method: 'DELETE',
        headers: { 'cookie': cookieHeader },
    })

    const res = await response.json()

    if (!response.ok) {
        return { err: res.message }
    }

    revalidatePath('/profile/config')

    return { data: res }
}

export async function deleteUser() {
    const cookieStore = await cookies()
    const cookieHeader = getCookieHeader(cookieStore.getAll())

    const response = await fetch(`${env.NEXT_PUBLIC_DOMAIN_FRONT}/api/user/delete`, {
        method: 'DELETE',
        headers: { 'cookie': cookieHeader },
    })

    const res = await response.json()
    if (!response.ok) return { err: res.message }
}
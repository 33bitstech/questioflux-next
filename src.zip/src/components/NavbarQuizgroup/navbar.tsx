import { headers } from 'next/headers'
import styles from './navbar.module.scss'
import { userAgent } from 'next/server'
import { Link } from '@/i18n/navigation'
import QuizIcon from '../Icons/QuizIcon'
import { cookies } from 'next/headers'
import ToggleMenuAsideContainer from './client/toggle-menu-aside-container'
import LogoutWidget from './client/logout-widget'
import ImgProfileConfig from './client/img-profile-config'
import SearchQuiz from './client/search-quiz'
import { getTranslations } from 'next-intl/server' // Importar

interface IProps {
    locale: string;
}

// O componente do layout que renderiza a Navbar passará os params
export default async function NavbarQuizgroup({ locale }: IProps) {
    const t = await getTranslations({ locale, namespace: 'navbar' });
    const headerList = await headers()
    const { device } = userAgent({ headers: headerList });
    const isMobile = device.type === 'mobile';
    const cookieStore = await cookies();
    
    const isLoggedIn = cookieStore.get('logged_in')?.value;

    const pagesWithSearchInput = ['/explore']

    return (
        <nav className={styles.navbar}>
            <ul className={styles.menus}>
                {/* A lógica de renderização mobile/desktop permanece a mesma */}
                {isMobile && (<>
                    {!isLoggedIn && <li><Link href='/' locale={locale}><QuizIcon/></Link></li>}
                    {isLoggedIn && <ToggleMenuAsideContainer styles={styles} token={isLoggedIn} className='menu_button_container'/>}
                </>)}
                {!isMobile && (<>
                    <li><Link locale={locale} href={isLoggedIn ? '/home' : '/'}><QuizIcon/></Link></li>
                    {isLoggedIn && <ToggleMenuAsideContainer styles={styles} token={isLoggedIn} className='menu_button_container'/>}
                </>)}
            </ul>
            <ul className={styles.actions}>
                <SearchQuiz 
                    styles={styles} 
                    placeholder={t('searchPlaceholder')} 
                    pagesWithSearchInput={pagesWithSearchInput}
                />
                {isLoggedIn ? (
                    <>
                        {!isMobile && <>
                            <li>
                                <Link locale={locale} href='/create/quiz' className={`${styles.button} ${styles.first_button}`}>{t('createQuiz')}</Link>
                            </li>
                            <li>
                                <Link locale={locale} href='/profile/config'><ImgProfileConfig styles={styles}/></Link>
                            </li>
                            <li>
                                {/* Assumindo que LogoutWidget receberá o texto como prop */}
                                <LogoutWidget styles={styles} text={t('logout')} />
                            </li>
                        </>}
                    </>
                ) : (
                    <>
                        <li>
                            <Link locale={locale} href='/register' className={`${styles.button} ${styles.first_button}`}>{t('createAccount')}</Link>
                        </li>
                        <li>
                            <Link locale={locale} href='/login' className={`${styles.second_button}`}>{t('login')}</Link>
                        </li>
                        <ToggleMenuAsideContainer styles={styles} className='config_container'/>
                    </>
                )}
            </ul>
        </nav> 
    )
}